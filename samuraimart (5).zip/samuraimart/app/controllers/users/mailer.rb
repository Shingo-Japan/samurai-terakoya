  class Users::Mailer < Devise::Mailer
  end
  